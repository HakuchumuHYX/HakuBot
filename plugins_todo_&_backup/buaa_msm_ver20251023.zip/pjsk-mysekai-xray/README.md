# pjsk-mysekai-xray
Usage: run `parse.py` in mitmproxy (fill the necessary thing first) -> input json dump into web -> item mapping  
Site: https://middlered.github.io/pjsk-mysekai-xray/paint.html  
## Special thanks
GPT-4o mini - 写了 90% 的 html 代码。  
DeepSeek R1 - 写了 7% 的 html 代码然后卡炸了。  
