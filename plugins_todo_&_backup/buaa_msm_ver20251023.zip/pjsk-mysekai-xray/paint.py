import json
from PIL import Image, ImageDraw, ImageFont
import os

# --- Data Structures Ported from JavaScript ---

# Scene parameters
SCENES = {
    'scene1': {
        "physicalWidth": 33.333,
        "offsetX": 0,
        "offsetY": -40,
        "imagePath": "img/grassland.png",
        "xDirection": 'x-',
        "yDirection": 'y-',
        "reverseXY": True,
    },
    'scene2': {
        "physicalWidth": 24.806,
        "offsetX": -62.015,
        "offsetY": 20.672,
        "imagePath": "img/flowergarden.png",
        "xDirection": 'x-',
        "yDirection": 'y-',
        "reverseXY": True,
    },
    'scene3': {
        "physicalWidth": 20.513,
        "offsetX": 0,
        "offsetY": 80,
        "imagePath": "img/beach.png",
        "xDirection": 'x+',
        "yDirection": 'y-',
        "reverseXY": False,
    },
    'scene4': {
        "physicalWidth": 21.333,
        "offsetX": 0,
        "offsetY": -106.667,
        "imagePath": "img/memorialplace.png",
        "xDirection": 'x+',
        "yDirection": 'y-',
        "reverseXY": False,
    }
}

# Colors for fixture IDs
FIXTURE_COLORS = {
    112: '#f9f9f9',
    1001: '#da6d42', 1002: '#da6d42', 1003: '#da6d42', 1004: '#da6d42',
    2001: '#878685', 2002: '#d5750a', 2003: '#d5d5d5', 2004: '#a7c7cb', 2005: '#9933cc',
    3001: '#c95a49',
    4001: '#f8729a', 4002: '#f8729a', 4003: '#f8729a', 4004: '#f8729a',
    4005: '#f8729a', 4006: '#f8729a', 4007: '#f8729a', 4008: '#f8729a',
    4009: '#f8729a', 4010: '#f8729a', 4011: '#f8729a', 4012: '#f8729a',
    4013: '#f8729a', 4014: '#f8729a', 4015: '#f8729a', 4016: '#f8729a',
    4017: '#f8729a', 4018: '#f8729a', 4019: '#f8729a', 4020: '#f8729a',
    5001: '#f6f5f2', 5002: '#f6f5f2', 5003: '#f6f5f2', 5004: '#f6f5f2',
    5101: '#f6f5f2', 5102: '#f6f5f2', 5103: '#f6f5f2', 5104: '#f6f5f2',
    6001: '#6f4e37',
    7001: '#a5d5ff', # 修正了原始JS中的拼写错误
}

# Paths to item icons
ITEM_TEXTURES = {
    'mysekai_material': {
        "1": "./icon/Texture2D/item_wood_1.png", "2": "./icon/Texture2D/item_wood_2.png",
        "3": "./icon/Texture2D/item_wood_3.png", "4": "./icon/Texture2D/item_wood_4.png",
        "5": "./icon/Texture2D/item_wood_5.png", "6": "./icon/Texture2D/item_mineral_1.png",
        "7": "./icon/Texture2D/item_mineral_2.png", "8": "./icon/Texture2D/item_mineral_3.png",
        "9": "./icon/Texture2D/item_mineral_4.png", "10": "./icon/Texture2D/item_mineral_5.png",
        "11": "./icon/Texture2D/item_mineral_6.png", "12": "./icon/Texture2D/item_mineral_7.png",
        "13": "./icon/Texture2D/item_junk_1.png", "14": "./icon/Texture2D/item_junk_2.png",
        "15": "./icon/Texture2D/item_junk_3.png", "16": "./icon/Texture2D/item_junk_4.png",
        "17": "./icon/Texture2D/item_junk_5.png", "18": "./icon/Texture2D/item_junk_6.png",
        "19": "./icon/Texture2D/item_junk_7.png", "20": "./icon/Texture2D/item_plant_1.png",
        "21": "./icon/Texture2D/item_plant_2.png", "22": "./icon/Texture2D/item_plant_3.png",
        "23": "./icon/Texture2D/item_plant_4.png", "24": "./icon/Texture2D/item_tone_8.png",
        "32": "./icon/Texture2D/item_junk_8.png", "33": "./icon/Texture2D/item_mineral_8.png",
        "34": "./icon/Texture2D/item_junk_9.png", "61": "./icon/Texture2D/item_junk_10.png",
        "62": "./icon/Texture2D/item_junk_11.png", "63": "./icon/Texture2D/item_junk_12.png",
        "64": "./icon/Texture2D/item_mineral_9.png", "65": "./icon/Texture2D/item_mineral_10.png",
    },
    'mysekai_item': {
        "7": "./icon/Texture2D/item_blueprint_fragment.png",
    },
    'mysekai_fixture': {
        "118": "./icon/Texture2D/mdl_non1001_before_sapling1_118.png",
        "119": "./icon/Texture2D/mdl_non1001_before_sapling1_119.png",
        "120": "./icon/Texture2D/mdl_non1001_before_sapling1_120.png",
        "121": "./icon/Texture2D/mdl_non1001_before_sapling1_121.png",
        "126": "./icon/Texture2D/mdl_non1001_before_sprout1_126.png",
        "127": "./icon/Texture2D/mdl_non1001_before_sprout1_127.png",
        "128": "./icon/Texture2D/mdl_non1001_before_sprout1_128.png",
        "129": "./icon/Texture2D/mdl_non1001_before_sprout1_129.png",
        "130": "./icon/Texture2D/mdl_non1001_before_sprout1_130.png",
        "474": "./icon/Texture2D/mdl_non1001_before_sprout1_474.png",
        "475": "./icon/Texture2D/mdl_non1001_before_sprout1_475.png",
        "476": "./icon/Texture2D/mdl_non1001_before_sprout1_476.png",
        "477": "./icon/Texture2D/mdl_non1001_before_sprout1_477.png",
        "478": "./icon/Texture2D/mdl_non1001_before_sprout1_478.png",
        "479": "./icon/Texture2D/mdl_non1001_before_sprout1_479.png",
        "480": "./icon/Texture2D/mdl_non1001_before_sprout1_480.png",
        "481": "./icon/Texture2D/mdl_non1001_before_sprout1_481.png",
        "482": "./icon/Texture2D/mdl_non1001_before_sprout1_482.png",
        "483": "./icon/Texture2D/mdl_non1001_before_sprout1_483.png"
    },
    'mysekai_music_record': {
        352: 'music352.png' # This path isn't used, logic overrides it
    }
}

# Rarity definitions
RARE_ITEM = {
    'mysekai_material': [5, 12, 20, 24, 32, 33, 61, 62, 63, 64, 65],
    'mysekai_item': [7],
    'mysekai_music_record': [],
    'mysekai_fixture': [118, 119, 120, 121]
}

SUPER_RARE_ITEM = {
    'mysekai_material': [5, 12, 20, 24],
    'mysekai_item': [],
    'mysekai_fixture': [],
    'mysekai_music_record': []
}

# --- Helper Functions ---

def do_contains_rare_item(reward, is_super_rare=False):
    """Checks if a reward object contains any rare or super-rare items."""
    compare_list = SUPER_RARE_ITEM if is_super_rare else RARE_ITEM
    for category, items in reward.items():
        if category in compare_list:
            for item_id_str in items.keys():
                if int(item_id_str) in compare_list[category]:
                    return True
    return False

def get_font(size=8):
    """Tries to load a font, falls back to default if not found."""
    try:
        # You may need to change "arial.ttf" to a font path on your system
        return ImageFont.truetype("arial.ttf", size)
    except IOError:
        print("Arial font not found, using default font.")
        return ImageFont.load_default()

def get_icon(path, size=(20, 20)):
    """Loads an icon image, returns a placeholder if not found."""
    try:
        icon = Image.open(path).convert("RGBA")
        icon = icon.resize(size, Image.Resampling.LANCZOS)
    except FileNotFoundError:
        print(f"Icon not found: {path}, using placeholder.")
        icon = Image.new('RGBA', size, (255, 0, 255, 255)) # Magenta placeholder
    return icon

# --- 新增：物品栏位置调整函数 ---
def adjust_item_list_positions(render_list, scene, max_lap_width=5, max_lap_height=5):
    """
    调整奖励物品框的位置以避免重叠。
    这是 `adjustItemListPositions` 函数的 Python 实现。
    """
    reverse_xy = scene['reverseXY']
    
    # 嵌套循环，与JS逻辑一致
    for i in range(len(render_list)):
        # 只有带物品框的才需要检查
        if not render_list[i].get('box_rect'):
            continue
            
        rect1 = render_list[i]['box_rect'] # [left, top, right, bottom]

        for j in range(i + 1, len(render_list)):
            if not render_list[j].get('box_rect'):
                continue
                
            rect2 = render_list[j]['box_rect']

            # 计算重叠
            r1_left, r1_top, r1_right, r1_bottom = rect1
            r2_left, r2_top, r2_right, r2_bottom = rect2

            overlap_width = min(r1_right, r2_right) - max(r1_left, r2_left)
            overlap_height = min(r1_bottom, r2_bottom) - max(r1_top, r2_top)

            # 检查重叠是否超出阈值
            if overlap_width > max_lap_width and overlap_height > max_lap_height:
                # 发现重叠，调整 rect2 (即 render_list[j])
                
                if reverse_xy:
                    # Nudge 'j' up
                    nudge_amount = (overlap_height / 1.25)
                    r2_top -= nudge_amount
                    r2_bottom -= nudge_amount
                else:
                    # Nudge 'j' left
                    nudge_amount = (overlap_width / 1.25)
                    r2_left -= nudge_amount
                    r2_right -= nudge_amount
                
                # 将调整后的坐标更新回列表，以便后续检查
                render_list[j]['box_rect'] = [r2_left, r2_top, r2_right, r2_bottom]
    
    return render_list # 返回调整后的列表

# --- Main Function (Modified) ---

def generate_map_preview(scene_id, map_data, output_filename="map_preview.png"):
    """
    Generates a map preview image with points and rewards.
    
    Args:
        scene_id (str): The key for the scene (e.g., 'scene1').
        map_data (list): A list of point dictionaries (from the JSON).
        output_filename (str): The name of the file to save.
    """
    if scene_id not in SCENES:
        print(f"Error: Scene ID '{scene_id}' not found.")
        return

    scene = SCENES[scene_id]

    # Load the base image
    try:
        base_img = Image.open(scene['imagePath']).convert('RGBA')
    except FileNotFoundError:
        print(f"Error: Base image not found at {scene['imagePath']}")
        print("Please ensure the 'img' folder is in the same directory.")
        return

    draw = ImageDraw.Draw(base_img, 'RGBA')
    
    # Load fonts
    qty_font = get_font(8)

    # Get scene parameters
    grid_px = scene['physicalWidth']
    origin_x = base_img.width / 2 + scene['offsetX']
    origin_y = base_img.height / 2 + scene['offsetY']
    reverse_xy = scene['reverseXY']
    x_dir = scene['xDirection']
    y_dir = scene['yDirection']

    # --- 阶段 1: 计算所有渲染元素的位置 ---
    render_list = []
    
    for point in map_data:
        location = point['location']
        fixture_id = point['fixtureId']
        reward = point.get('reward', {})

        # 1. 坐标转换
        x, y = (location[1], location[0]) if reverse_xy else (location[0], location[1])
        
        display_x = origin_x + x * grid_px if x_dir == 'x+' else origin_x - x * grid_px
        display_y = origin_y + y * grid_px if y_dir == 'y+' else origin_y - y * grid_px

        # 2. 点的颜色和边框
        color = FIXTURE_COLORS.get(fixture_id, '#000000')
        is_rare = do_contains_rare_item(reward)
        border_color = 'red' if is_rare else 'black'
        
        render_item = {
            'point_coords': (display_x, display_y),
            'point_color': color,
            'point_border': border_color,
            'box_rect': None,
            'box_bg': None,
            'items_to_draw': []
        }

        # 3. 准备奖励物品
        items_to_draw = []
        for category, items in reward.items():
            for item_id_str, quantity in items.items():
                texture_path = None
                if category == "mysekai_music_record":
                    texture_path = './icon/Texture2D/item_surplus_music_record.png'
                else:
                    texture_path = ITEM_TEXTURES.get(category, {}).get(item_id_str)
                
                if texture_path:
                    items_to_draw.append((texture_path, quantity))
                else:
                    print(f"Warning: No texture for {category} - {item_id_str}")

        if not items_to_draw:
            render_list.append(render_item)
            continue
            
        render_item['items_to_draw'] = items_to_draw

        # 4. 奖励框背景
        is_super_rare = do_contains_rare_item(reward, is_super_rare=True)
        has_music = "mysekai_music_record" in reward
        
        if is_super_rare:
            bg_color = (255, 0, 0, 192) 
        elif is_rare or has_music:
            bg_color = (0, 0, 180, 192)
        else:
            bg_color = (138, 138, 138, 216)
        
        render_item['box_bg'] = bg_color

        # 5. 计算奖励框位置和尺寸
        icon_size = 20
        padding = 2
        num_items = len(items_to_draw)
        
        box_x = display_x + grid_px / 2
        box_y = display_y + grid_px / 3
        if reverse_xy:
            box_y -= 10

        if reverse_xy: # Horizontal layout
            box_w = (icon_size * num_items) + (padding * (num_items + 1))
            box_h = icon_size + 2 * padding
        else: # Vertical layout
            box_w = icon_size + 2 * padding
            box_h = (icon_size * num_items) + (padding * (num_items + 1))
            
        render_item['box_rect'] = [box_x, box_y, box_x + box_w, box_y + box_h]
        
        render_list.append(render_item)

    # --- 阶段 2: 调整物品框位置 ---
    adjusted_render_list = adjust_item_list_positions(render_list, scene)

    # --- 阶段 3: 执行所有绘制操作 ---
    for item in adjusted_render_list:

        # 2. 检查是否有物品框要绘制
        if not item['box_rect']:
            continue
            
        # 3. 绘制物品框
        box_rect = item['box_rect']
        draw.rectangle(box_rect, fill=item['box_bg'])
        
        # 4. 绘制图标和数量
        icon_size = 20
        padding = 2
        box_x, box_y = box_rect[0], box_rect[1] # 获取调整后的左上角
        
        current_x = box_x + padding
        current_y = box_y + padding

        for texture_path, quantity in item['items_to_draw']:
            icon = get_icon(texture_path, (icon_size, icon_size))
            base_img.paste(icon, (int(current_x), int(current_y)), icon)
            
            # 绘制数量
            qty_str = str(quantity)
            text_bbox = qty_font.getbbox(qty_str)
            text_w = text_bbox[2] - text_bbox[0]
            text_h = text_bbox[3] - text_bbox[1]
            
            text_x = current_x + icon_size - text_w - 2
            text_y = current_y + icon_size - text_h - 2
            
            draw.rectangle(
                [text_x - 1, text_y - 1, text_x + text_w + 1, text_y + text_h + 1],
                fill=(255, 255, 255, 192)
            )
            draw.text((text_x, text_y), qty_str, fill='black', font=qty_font)

            if reverse_xy:
                current_x += icon_size + padding
            else:
                current_y += icon_size + padding
				
    for item in adjusted_render_list:
        # 1. 绘制点
        display_x, display_y = item['point_coords']
        radius = 5
        bbox = [display_x - radius, display_y - radius, display_x + radius, display_y + radius]
        draw.ellipse(bbox, fill=item['point_color'], outline=item['point_border'], width=1)

    # --- 阶段 4: 保存图像 ---
    base_img.convert('RGB')
    base_img.save(output_filename)
    print(f"Successfully saved map preview to '{output_filename}'")

# --- Example Usage ---

if __name__ == "__main__":
    # 示例数据，包含两个靠近的点以测试重叠
    sample_map_data = [{"location": [10, -27], "fixtureId": 2002, "reward": {"mysekai_material": {"6": 6, "7": 3}}}, {"location": [9, -28], "fixtureId": 2002, "reward": {"mysekai_material": {"6": 6, "7": 1}}}, {"location": [-28, -13], "fixtureId": 2003, "reward": {"mysekai_material": {"6": 6, "8": 2}}}, {"location": [-30, -14], "fixtureId": 2003, "reward": {"mysekai_material": {"6": 6, "8": 2}}}, {"location": [-28, -19], "fixtureId": 2001, "reward": {"mysekai_material": {"6": 6, "9": 1}}}, {"location": [0, 13], "fixtureId": 2004, "reward": {"mysekai_material": {"6": 6, "10": 2}, "mysekai_item": {"7": 1}}}, {"location": [4, 7], "fixtureId": 3001, "reward": {"mysekai_material": {"13": 2}}}, {"location": [0, -24], "fixtureId": 3001, "reward": {"mysekai_material": {"13": 1}}}, {"location": [-3, 2], "fixtureId": 3001, "reward": {"mysekai_material": {"13": 1}}}, {"location": [-3, 5], "fixtureId": 3001, "reward": {"mysekai_material": {"14": 2}}}, {"location": [-3, -7], "fixtureId": 3001, "reward": {"mysekai_material": {"14": 2, "63": 1}}}, {"location": [8, -23], "fixtureId": 3001, "reward": {"mysekai_material": {"14": 2, "63": 1}}}, {"location": [3, -2], "fixtureId": 3001, "reward": {"mysekai_material": {"15": 1, "62": 1}}}, {"location": [5, -22], "fixtureId": 3001, "reward": {"mysekai_material": {"15": 1}}}, {"location": [-3, -19], "fixtureId": 3001, "reward": {"mysekai_material": {"15": 1}}}, {"location": [-10, 4], "fixtureId": 5004, "reward": {"mysekai_material": {"16": 1, "63": 1}}}, {"location": [-12, -7], "fixtureId": 5004, "reward": {"mysekai_material": {"16": 1, "63": 1}}}, {"location": [-20, -20], "fixtureId": 5004, "reward": {"mysekai_material": {"16": 1}}}, {"location": [-6, 8], "fixtureId": 5004, "reward": {"mysekai_material": {"17": 1, "63": 1}}}, {"location": [-11, -21], "fixtureId": 5004, "reward": {"mysekai_material": {"17": 1, "62": 1}}}, {"location": [6, -10], "fixtureId": 5004, "reward": {"mysekai_material": {"17": 1, "62": 1}}}, {"location": [-19, -16], "fixtureId": 5004, "reward": {"mysekai_material": {"18": 2}}}, {"location": [-8, 5], "fixtureId": 5004, "reward": {"mysekai_material": {"18": 1, "62": 1}}}, {"location": [7, -3], "fixtureId": 5004, "reward": {"mysekai_material": {"18": 1}}}, {"location": [-6, 5], "fixtureId": 5004, "reward": {"mysekai_material": {"19": 1, "63": 1}}}, {"location": [-9, 1], "fixtureId": 5004, "reward": {"mysekai_material": {"19": 1}}}, {"location": [-9, -11], "fixtureId": 5004, "reward": {"mysekai_material": {"19": 2}}}, {"location": [-10, 10], "fixtureId": 7001, "reward": {"mysekai_material": {"24": 1}}}, {"location": [15, 2], "fixtureId": 112, "reward": {"mysekai_music_record": {"66": 1}}}]


    # 确保输出目录存在
    if not os.path.exists("output"):
        os.makedirs("output")

    # 为 Scene 1 生成预览 (reverseXY = True)
    print("Generating preview for Scene 4...")
    generate_map_preview(
        scene_id='scene4', 
        map_data=sample_map_data, 
        output_filename="output/scene4_preview.png"
    )