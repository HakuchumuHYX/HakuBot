import http.server
import socketserver
import os
import re
import json
import msgpack
import msgspec
from urllib.parse import urlparse
from datetime import datetime
from typing import List, Optional
from pathlib import Path


# 数据模型定义
class GridSize(msgspec.Struct):
    width: int
    depth: int
    height: int

class MysekaiFixtureTagGroup(msgspec.Struct):
    id: int
    mysekaiFixtureTagId1: int
    mysekaiFixtureTagId2: Optional[int] = None
    mysekaiFixtureTagId3: Optional[int] = None

class ModelItem(msgspec.Struct, kw_only=True):
    id: int
    mysekaiFixtureType: str
    name: str
    pronunciation: str
    flavorText: str
    seq: int
    gridSize: GridSize
    mysekaiFixtureMainGenreId: Optional[int] = None
    mysekaiFixtureSubGenreId: Optional[int] = None
    mysekaiFixtureHandleType: str
    mysekaiSettableSiteType: str
    mysekaiSettableLayoutType: str
    mysekaiFixturePutType: str
    mysekaiFixtureAnotherColors: List
    mysekaiFixturePutSoundId: int
    mysekaiFixtureFootstepId: Optional[int] = None
    mysekaiFixtureTagGroup: Optional[MysekaiFixtureTagGroup] = None
    isAssembled: bool
    isDisassembled: bool
    mysekaiFixturePlayerActionType: str
    isGameCharacterAction: bool
    assetbundleName: str

class UserMysekaiSiteHarvestFixture(msgspec.Struct):
    mysekaiSiteHarvestFixtureId: int
    positionX: int
    positionZ: int
    hp: int
    userMysekaiSiteHarvestFixtureStatus: str

class UserMysekaiSiteHarvestResourceDrop(msgspec.Struct):
    resourceType: str
    resourceId: int
    positionX: int
    positionZ: int
    hp: int
    seq: int
    mysekaiSiteHarvestResourceDropStatus: str
    quantity: int

class Map(msgspec.Struct, kw_only=True):
    mysekaiSiteId: int
    siteName: Optional[str] = None
    userMysekaiSiteHarvestFixtures: List[UserMysekaiSiteHarvestFixture]
    userMysekaiSiteHarvestResourceDrops: List[UserMysekaiSiteHarvestResourceDrop]

# 站点ID映射
SITE_ID = {
    1: "マイホーム",
    2: "1F",
    3: "2F",
    4: "3F",
    5: "さいしょの原っぱ",
    6: "願いの砂浜",
    7: "彩りの花畑",
    8: "忘れ去られた場所",
}

class ItemDetail(msgspec.Struct):
    id: int
    seq: int
    mysekaiItemType: str
    name: str
    pronunciation: str
    description: str
    iconAssetbundleName: str

class MaterialDetail(msgspec.Struct, kw_only=True):
    id: int
    seq: int
    mysekaiMaterialType: str
    name: str
    pronunciation: str
    description: str
    mysekaiMaterialRarityType: str
    iconAssetbundleName: str
    modelAssetbundleName: Optional[str] = None
    mysekaiSiteIds: List[int]
    mysekaiPhenomenaGroupId: Optional[int] = None

class HarvestObjectDetail(msgspec.Struct):
    id: int
    mysekaiSiteHarvestFixtureType: str
    hp: int
    lastAttackStamina: int
    mysekaiSiteHarvestFixtureRarityType: str
    assetbundleName: str

# 工具函数
def extract_api_type(url):
    if re.search(r'/mysekai(\?|$)', url):
        return 'mysekai'
    if re.search(r'/suite/', url):
        return 'suite'
    return 'unknown'

def generate_filename(api_type, original_url, ext='bin'):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    user_id = re.search(r'/user/(\d+)', original_url)
    user_str = f"_user{user_id.group(1)}" if user_id else ""
    return f"{api_type}{user_str}_{timestamp}_{os.getpid()}.{ext}"

# 解密函数
def decrypt_packet(infile, region='jp'):
    try:
        from sssekai.crypto.APIManager import decrypt, SEKAI_APIMANAGER_KEYSETS
        
        data = open(infile, "rb").read()
        plain = decrypt(data, SEKAI_APIMANAGER_KEYSETS[region])
        
        try:
            msg = msgpack.unpackb(plain)
            return msg
        except Exception:
            print("Malformed decrypted data")
            print("Please consider switching to another region with `--region` flag (i.e. `--region en`)")
            return None
    except ImportError:
        print("sssekai module not found, cannot decrypt packet")
        return None
    except Exception as e:
        print(f"Error decrypting packet: {str(e)}")
        return None

# 解析函数
def parse_map(user_data: dict):
    assert user_data["updatedResources"]["userMysekaiHarvestMaps"]

    harvest_maps: List[Map] = [ 
        msgspec.json.decode(msgspec.json.encode(mp), type=Map) 
        for mp in user_data["updatedResources"]["userMysekaiHarvestMaps"]
    ]

    for mp in harvest_maps:
        mp.siteName = SITE_ID.get(mp.mysekaiSiteId, f"Unknown Site {mp.mysekaiSiteId}")

    processed_map = {}
    for mp in harvest_maps:
        mp_detail = []
        for fixture in mp.userMysekaiSiteHarvestFixtures:
            if fixture.userMysekaiSiteHarvestFixtureStatus == "spawned":
                mp_detail.append({
                    "location": (fixture.positionX, fixture.positionZ),
                    "fixtureId": fixture.mysekaiSiteHarvestFixtureId,
                    "reward": {}
                })
            
        for drop in mp.userMysekaiSiteHarvestResourceDrops:
            pos = (drop.positionX, drop.positionZ)
            for i in range(len(mp_detail)):
                if mp_detail[i]["location"] != pos:
                    continue
                
                mp_detail[i]["reward"].setdefault(drop.resourceType, {})
                mp_detail[i]["reward"][drop.resourceType][drop.resourceId] = \
                    mp_detail[i]["reward"][drop.resourceType].get(drop.resourceId, 0) + drop.quantity
                break
        
        processed_map[mp.siteName] = mp_detail
    
    return processed_map

def process_decrypted_data(data, output_file):
    try:
        if "updatedResources" not in data or "userMysekaiHarvestMaps" not in data["updatedResources"]:
            print("No harvest maps information found in the data")
            return False

        with open(output_file, 'w', encoding='utf-8') as fout:
            print(f"Find Harvest Maps Info", file=fout)
            result = parse_map(data)
            for k, v in result.items():
                print(f"Site: {k}", file=fout)
                print(json.dumps(v, indent=None, ensure_ascii=False), file=fout)
                print("\n", file=fout)
        
        return True
    except Exception as e:
        print(f"Error processing decrypted data: {str(e)}")
        return False

# 请求处理器
class RequestHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/upload.js':
            js_content = """
            const upload = () => {
                $httpClient.post({
                    url: "http://%s:%d/upload",
                    headers: { 
                        "X-Original-Url": $request.url,
                        "X-Request-Path": $request.path
                    },
                    body: $response.body
                }, (error) => $done({}));
            };
            upload();
            """ % (LOCAL_IP, PORT)

            js_content = js_content.strip()
            self.send_response(200)
            self.send_header('Content-Type', 'application/javascript; charset=utf-8')
            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
            self.send_header('Content-Length', str(len(js_content.encode('utf-8'))))
            self.end_headers()
            self.wfile.write(js_content.encode('utf-8'))
            return

        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        original_url = self.headers.get('X-Original-Url', '')
        api_type = extract_api_type(original_url)
        bin_filename = generate_filename(api_type, original_url, 'bin')
        
        # 读取并保存原始数据
        content_length = int(self.headers['Content-Length'])
        received_data = self.rfile.read(content_length)
        
        with open(bin_filename, 'wb') as f:
            f.write(received_data)
        
        print(f"Saved [{api_type.upper()}]: {bin_filename}")
        print(f"Source URL: {original_url[:100]}{'...' if len(original_url) > 100 else ''}")
        print(f"File Size: {len(received_data)/1024:.2f} KB")
        
        # 仅对mysekai类型的包进行解密和解析
        if api_type == 'mysekai':
            print("Processing mysekai packet...")
            
            # 解密
            #json_filename = generate_filename(api_type, original_url, 'json')
            json_file = decrypt_packet(bin_filename)#, json_filename)
            if json_file is not None:
                
                # 解析并导出
                output_filename = generate_filename(api_type, original_url, 'txt')
                if process_decrypted_data(json_file, output_filename):
                    print(f"Processed output saved to: {output_filename}")
            print()
        
        self.send_response(200)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.end_headers()

if __name__ == "__main__":
    print(f"Universal Data Receiver running at http://0.0.0.0:{PORT}")
    print("File naming format: [api_type]_[user]_[timestamp]_[pid].ext\n")
    try:
        with socketserver.TCPServer(("", PORT), RequestHandler) as httpd:
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped by user")

